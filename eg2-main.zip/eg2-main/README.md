eg2
