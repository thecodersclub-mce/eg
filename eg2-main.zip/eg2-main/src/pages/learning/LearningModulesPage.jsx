import React from 'react';
import { Link } from 'react-router-dom';

const modules = [
  {
    id: 'java',
    title: 'Java Programming',
    description: 'Learn Java programming from basics to advanced concepts',
    image: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg',
  },
  {
    id: 'python',
    title: 'Python Programming',
    description: 'Master Python programming with hands-on projects',
    image: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg',
  },
];

export default function LearningModulesPage() {
  return (
    <div className="container py-12">
      <h1 className="text-3xl font-bold mb-8">Learning Modules</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {modules.map((module) => (
          <Link
            key={module.id}
            to={`/learning/${module.id}`}
            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition"
          >
            <img
              src={module.image}
              alt={module.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h2 className="text-xl font-bold mb-2">{module.title}</h2>
              <p className="text-gray-600">{module.description}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}