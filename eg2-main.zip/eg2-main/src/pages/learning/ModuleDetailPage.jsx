import React from 'react';
import { useParams } from 'react-router-dom';
import YouTube from 'react-youtube';

const moduleContent = {
  java: {
    title: 'Java Programming',
    description: 'Learn Java programming from basics to advanced concepts',
    videos: [
      { id: 'eIrMbAQSU34', title: 'Java Tutorial for Beginners' },
      { id: 'grEKMHGYyns', title: 'Java OOP Concepts' },
    ],
  },
  python: {
    title: 'Python Programming',
    description: 'Master Python programming with hands-on projects',
    videos: [
      { id: 'kqtD5dpn9C8', title: 'Python for Beginners' },
      { id: 'JJmcL1N2KQs', title: 'Python OOP Tutorial' },
    ],
  },
};

export default function ModuleDetailPage() {
  const { moduleId } = useParams();
  const module = moduleContent[moduleId];

  if (!module) {
    return <div className="container py-12">Module not found</div>;
  }

  return (
    <div className="container py-12">
      <h1 className="text-3xl font-bold mb-4">{module.title}</h1>
      <p className="text-gray-600 mb-8">{module.description}</p>
      <div className="space-y-8">
        {module.videos.map((video) => (
          <div key={video.id} className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold mb-4">{video.title}</h2>
            <div className="aspect-w-16 aspect-h-9">
              <YouTube
                videoId={video.id}
                className="w-full"
                opts={{
                  width: '100%',
                  height: '400',
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}