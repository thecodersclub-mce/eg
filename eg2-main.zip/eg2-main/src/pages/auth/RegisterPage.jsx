import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

export default function RegisterPage() {
  const navigate = useNavigate();
  const { register } = useAuth();

  const formik = useFormik({
    initialValues: {
      name: '',
      department: '',
      year: '',
      email: '',
      password: '',
    },
    validationSchema: Yup.object({
      name: Yup.string().required('Required'),
      department: Yup.string().required('Required'),
      year: Yup.string().required('Required'),
      email: Yup.string().email('Invalid email address').required('Required'),
      password: Yup.string().min(6, 'Must be at least 6 characters').required('Required'),
    }),
    onSubmit: async (values) => {
      const success = await register(values);
      if (success) {
        navigate('/login');
      } else {
        alert('Registration failed');
      }
    },
  });

  return (
    <div className="container py-12">
      <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-6">Register</h2>
        <form onSubmit={formik.handleSubmit}>
          <div className="mb-4">
            <label htmlFor="name" className="block mb-2">Name</label>
            <input
              id="name"
              type="text"
              {...formik.getFieldProps('name')}
              className="w-full px-3 py-2 border rounded"
            />
            {formik.touched.name && formik.errors.name && (
              <div className="text-red-600">{formik.errors.name}</div>
            )}
          </div>
          <div className="mb-4">
            <label htmlFor="department" className="block mb-2">Department</label>
            <select
              id="department"
              {...formik.getFieldProps('department')}
              className="w-full px-3 py-2 border rounded"
            >
              <option value="">Select Department</option>
              <option value="cse">CSE</option>
              <option value="aiml">AI/ML</option>
            </select>
            {formik.touched.department && formik.errors.department && (
              <div className="text-red-600">{formik.errors.department}</div>
            )}
          </div>
          <div className="mb-4">
            <label htmlFor="year" className="block mb-2">Year</label>
            <select
              id="year"
              {...formik.getFieldProps('year')}
              className="w-full px-3 py-2 border rounded"
            >
              <option value="">Select Year</option>
              <option value="1">1st Year</option>
              <option value="2">2nd Year</option>
              <option value="3">3rd Year</option>
              <option value="4">4th Year</option>
            </select>
            {formik.touched.year && formik.errors.year && (
              <div className="text-red-600">{formik.errors.year}</div>
            )}
          </div>
          <div className="mb-4">
            <label htmlFor="email" className="block mb-2">Email</label>
            <input
              id="email"
              type="email"
              {...formik.getFieldProps('email')}
              className="w-full px-3 py-2 border rounded"
            />
            {formik.touched.email && formik.errors.email && (
              <div className="text-red-600">{formik.errors.email}</div>
            )}
          </div>
          <div className="mb-4">
            <label htmlFor="password" className="block mb-2">Password</label>
            <input
              id="password"
              type="password"
              {...formik.getFieldProps('password')}
              className="w-full px-3 py-2 border rounded"
            />
            {formik.touched.password && formik.errors.password && (
              <div className="text-red-600">{formik.errors.password}</div>
            )}
          </div>
          <button
            type="submit"
            className="w-full bg-primary text-white py-2 rounded hover:bg-blue-700"
          >
            Register
          </button>
        </form>
      </div>
    </div>
  );
}