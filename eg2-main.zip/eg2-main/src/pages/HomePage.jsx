import React from 'react';
import { Link } from 'react-router-dom';

export default function HomePage() {
  return (
    <div className="container py-12">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-6">Welcome to The Coders Club</h1>
        <p className="text-xl text-gray-600 mb-8">
          Learn programming with our comprehensive modules and join our community of developers.
        </p>
        <Link
          to="/learning"
          className="bg-primary text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition"
        >
          Start Learning
        </Link>
      </div>
    </div>
  );
}