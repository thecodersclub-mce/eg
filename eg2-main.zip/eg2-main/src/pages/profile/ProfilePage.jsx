import React from 'react';
import { useAuth } from '../../contexts/AuthContext';

export default function ProfilePage() {
  const { user } = useAuth();

  return (
    <div className="container py-12">
      <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-6">Profile</h2>
        <div className="space-y-4">
          <div>
            <label className="font-medium">Name</label>
            <p>{user.name}</p>
          </div>
          <div>
            <label className="font-medium">Email</label>
            <p>{user.email}</p>
          </div>
          <div>
            <label className="font-medium">Department</label>
            <p>{user.department}</p>
          </div>
          <div>
            <label className="font-medium">Year</label>
            <p>{user.year}</p>
          </div>
        </div>
      </div>
    </div>
  );
}