import axios from 'axios';

const SHEET_URL = 'https://script.google.com/macros/s/AKfycbzGQAUtopcCSxQuK9UDgYlngxQtpt7cxN6YtD1PTI4YqTFlqHhc7nmWTWkgNcmK2Bhk/exec';

export const googleSheetsApi = {
  async getUsers() {
    try {
      const response = await axios.get(SHEET_URL);
      return response.data || [];
    } catch (error) {
      console.error('Error fetching users:', error);
      return [];
    }
  },

  async addUser(userData) {
    try {
      const response = await axios.post(SHEET_URL, userData, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      return response.data?.success || false;
    } catch (error) {
      console.error('Error adding user:', error);
      return false;
    }
  }
};