import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

export default function Header() {
  const { user, logout } = useAuth();

  return (
    <header className="bg-white shadow">
      <nav className="container py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold text-primary">
            The Coders Club
          </Link>
          <div className="flex gap-6">
            <Link to="/learning" className="hover:text-primary">Learning</Link>
            <Link to="/about" className="hover:text-primary">About</Link>
            {user ? (
              <>
                <Link to="/profile" className="hover:text-primary">Profile</Link>
                <button onClick={logout} className="hover:text-primary">Logout</button>
              </>
            ) : (
              <Link to="/login" className="hover:text-primary">Login</Link>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
}